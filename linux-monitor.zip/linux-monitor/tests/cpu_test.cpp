#include "cpu.h"
#include <iostream>

int main(){
    CpuSnapshot prev{10, 0, 5, 85};
    CpuSnapshot curr{20, 0, 10, 95};
    double usage = calculateCpuUsage(prev, curr);
    
    double expected = 60.0;

    if (usage == expected) {
        std::cout << "CPU calculation test: PASS\n";
    } else {
        std::cout << "CPU calculation test: FAIL\n";
        std::cout << "Expected: " << expected << "%\n";
        std::cout << "Actual: " << usage << "%\n";
        return 1;
    }
    
    return 0;
}