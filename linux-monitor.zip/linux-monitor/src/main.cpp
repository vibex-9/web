#include <csignal>
#include <iostream>
#include <unistd.h>

#include "cpu.h"

volatile sig_atomic_t running = 1;

void handleSignal(int) {
    running = 0;
}

int main() {
    int cpuCount = getOnlineProcessorCount();

    std::cout << "Online processors: " << cpuCount << std::endl;

    signal(SIGINT, handleSignal);

    auto previous = getCpuSnapshot();

    if (!previous) {
        std::cerr << "Failed to read CPU statistics\n";
        return 1;
    }

    while (running) {
        sleep(2);

        auto current = getCpuSnapshot();

        if (!current) {
            std::cerr << "Failed to read CPU statistics\n";
            continue;
        }

        double usage = calculateCpuUsage(*previous, *current);

        std::cout << "CPU Usage: " << usage << "%\n";

        previous = current;
    }

    std::cout << "Exiting...\n";

    return 0;
}