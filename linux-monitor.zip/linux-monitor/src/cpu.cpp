#include "cpu.h"
#include <unistd.h>
#include <cstdio>
#include <iostream>

int getOnlineProcessorCount() {
    return sysconf(_SC_NPROCESSORS_ONLN);
}

std::optional<CpuSnapshot> getCpuSnapshot() {
    CpuSnapshot snapshot{};

    FILE* file = fopen("/proc/stat", "r");

    if (!file) {
        return std::nullopt;
    }

    int fieldsRead = fscanf(
        file,
        "cpu %llu %llu %llu %llu",
        &snapshot.user,
        &snapshot.nice,
        &snapshot.system,
        &snapshot.idle
    );

    fclose(file);

    if (fieldsRead != 4) {
        return std::nullopt;
    }

    return snapshot;
}

double calculateCpuUsage(const CpuSnapshot& previous, const CpuSnapshot& current)
{
    if(previous.idle > current.idle || previous.user > current.user || previous.nice > current.nice || previous.system > current.system) {
        std::cerr << "Error: Current CPU times are less than previous CPU times." << std::endl;
        return 0.0;
    }
    
    unsigned long long prevIdle = previous.idle;
    unsigned long long currIdle = current.idle;

    unsigned long long prevTotal = previous.user + previous.nice + previous.system + previous.idle;
    unsigned long long currTotal = current.user + current.nice + current.system + current.idle;

    unsigned long long totalDiff = currTotal - prevTotal;
    unsigned long long idleDiff = currIdle - prevIdle;

    if (totalDiff == 0) return 0.0;

    return (1.0 - static_cast<double>(idleDiff) / totalDiff) * 100.0;
}
