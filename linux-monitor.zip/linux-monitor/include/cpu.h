#pragma once

#include <optional>

int getOnlineProcessorCount();

struct CpuSnapshot {
    unsigned long long user;
    unsigned long long nice;
    unsigned long long system;
    unsigned long long idle;
};

std::optional<CpuSnapshot> getCpuSnapshot();

double calculateCpuUsage(const CpuSnapshot& previous, const CpuSnapshot& current);
